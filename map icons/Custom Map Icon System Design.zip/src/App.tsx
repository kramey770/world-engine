import React, { useState } from "react";
import {
  WEEdit, WERegenerate, WEStyle, WESettings, WEAdd, WEShow, WECreate, WEHeightmap,
  WEEditBiomes, WEEditBurgs, WEEditCoastlines, WEEditCultures, WEEditDiplomacy,
  WEEditEmblems, WEEditGoods, WEEditHeightmap, WEEditMarkers, WEEditMarkets,
  WEEditMeasurers, WEEditLabels, WEEditMilitary, WEEditNames, WEEditNotes,
  WEEditProvinces, WEEditReligions, WEEditRivers, WEEditRoutes, WEEditStates,
  WEEditTrade, WEEditUnits, WEEditZones,
  WERegenBurgs, WERegenCultures, WERegenEconomy, WERegenEmblems, WERegenGoods,
  WERegenIce, WERegenStateLabels, WERegenMarkers, WERegenMarkets, WERegenMilitary,
  WERegenPopulation, WERegenProduction, WERegenProvinces, WERegenRelief,
  WERegenReligions, WERegenRivers, WERegenRoutes, WERegenStates, WERegenZones,
  WEAddBurg, WEAddLabel, WEAddPOI, WEAddRiver, WEAddRoute,
  WEShowCells, WEShowCharts, WEShowMinimap,
  WECreateSubmap, WECreateTransform,
  WEHeightmapPreview, WEHeightmap3D, WEHeightmapFinish,
  WEConfigureWorld, WEDefaultCanvas, WEResetOptions,
  WENewMap, WEExport, WESave, WELoad, WEResetZoom,
  WELayerStates, WELayerProvinces, WELayerCultures, WELayerReligions,
  WELayerBiomes, WELayerHeightmap, WELayerRivers, WELayerLakes, WELayerRoutes,
  WELayerGoods, WELayerTrade, WELayerMilitary, WELayerEmblems, WELayerLabels,
  WELayerBurgIcons, WELayerMarkers, WELayerOcean, WELayerCompass, WELayerLandmass,
  WELayerTexture, WELayerCells, WELayerGrid, WELayerCoordinates, WELayerRelief,
  WELayerZones, WELayerBorders, WELayerTemperature, WELayerCoastline, WELayerIce,
  WELayerMarkets, WELayerPrecipitation, WELayerPopulation, WELayerFogging,
  WELayerRulers, WELayerDebug, WELayerScaleBar, WELayerVignette, WELayerLegend,
  WEIconProps,
} from "./icons/WorldEngineIcons";

type IconEntry = {
  label: string;
  Component: React.FC<WEIconProps>;
};

const MAIN_NAV: IconEntry[] = [
  { label: "Edit", Component: WEEdit },
  { label: "Regenerate", Component: WERegenerate },
  { label: "Style", Component: WEStyle },
  { label: "Settings", Component: WESettings },
  { label: "Add", Component: WEAdd },
  { label: "Show", Component: WEShow },
  { label: "Create", Component: WECreate },
  { label: "Heightmap", Component: WEHeightmap },
];

const EDIT_ICONS: IconEntry[] = [
  { label: "Biomes", Component: WEEditBiomes },
  { label: "Burgs", Component: WEEditBurgs },
  { label: "Coastlines", Component: WEEditCoastlines },
  { label: "Cultures", Component: WEEditCultures },
  { label: "Diplomacy", Component: WEEditDiplomacy },
  { label: "Emblems", Component: WEEditEmblems },
  { label: "Goods", Component: WEEditGoods },
  { label: "Heightmap", Component: WEEditHeightmap },
  { label: "Markers", Component: WEEditMarkers },
  { label: "Markets", Component: WEEditMarkets },
  { label: "Measurers", Component: WEEditMeasurers },
  { label: "Labels", Component: WEEditLabels },
  { label: "Military", Component: WEEditMilitary },
  { label: "Names", Component: WEEditNames },
  { label: "Notes", Component: WEEditNotes },
  { label: "Provinces", Component: WEEditProvinces },
  { label: "Religions", Component: WEEditReligions },
  { label: "Rivers", Component: WEEditRivers },
  { label: "Routes", Component: WEEditRoutes },
  { label: "States", Component: WEEditStates },
  { label: "Trade", Component: WEEditTrade },
  { label: "Units", Component: WEEditUnits },
  { label: "Zones", Component: WEEditZones },
];

const REGEN_ICONS: IconEntry[] = [
  { label: "Burgs", Component: WERegenBurgs },
  { label: "Cultures", Component: WERegenCultures },
  { label: "Economy", Component: WERegenEconomy },
  { label: "Emblems", Component: WERegenEmblems },
  { label: "Goods", Component: WERegenGoods },
  { label: "Ice", Component: WERegenIce },
  { label: "State Labels", Component: WERegenStateLabels },
  { label: "Markers", Component: WERegenMarkers },
  { label: "Markets", Component: WERegenMarkets },
  { label: "Military", Component: WERegenMilitary },
  { label: "Population", Component: WERegenPopulation },
  { label: "Production", Component: WERegenProduction },
  { label: "Provinces", Component: WERegenProvinces },
  { label: "Relief", Component: WERegenRelief },
  { label: "Religions", Component: WERegenReligions },
  { label: "Rivers", Component: WERegenRivers },
  { label: "Routes", Component: WERegenRoutes },
  { label: "States", Component: WERegenStates },
  { label: "Zones", Component: WERegenZones },
];

const ADD_ICONS: IconEntry[] = [
  { label: "Burg", Component: WEAddBurg },
  { label: "Label", Component: WEAddLabel },
  { label: "Point of Interest", Component: WEAddPOI },
  { label: "River", Component: WEAddRiver },
  { label: "Route", Component: WEAddRoute },
];

const SHOW_ICONS: IconEntry[] = [
  { label: "Cells", Component: WEShowCells },
  { label: "Charts", Component: WEShowCharts },
  { label: "Minimap", Component: WEShowMinimap },
];

const CREATE_ICONS: IconEntry[] = [
  { label: "Submap", Component: WECreateSubmap },
  { label: "Transform", Component: WECreateTransform },
];

const HEIGHTMAP_ICONS: IconEntry[] = [
  { label: "Preview", Component: WEHeightmapPreview },
  { label: "3D View", Component: WEHeightmap3D },
  { label: "Finish", Component: WEHeightmapFinish },
];

const SETTINGS_ICONS: IconEntry[] = [
  { label: "Configure World", Component: WEConfigureWorld },
  { label: "Default Canvas", Component: WEDefaultCanvas },
  { label: "Reset Options", Component: WEResetOptions },
];

const FILE_ICONS: IconEntry[] = [
  { label: "New Map", Component: WENewMap },
  { label: "Export", Component: WEExport },
  { label: "Save", Component: WESave },
  { label: "Load", Component: WELoad },
  { label: "Reset Zoom", Component: WEResetZoom },
];

const LAYER_ICONS: IconEntry[] = [
  { label: "States", Component: WELayerStates },
  { label: "Provinces", Component: WELayerProvinces },
  { label: "Cultures", Component: WELayerCultures },
  { label: "Religions", Component: WELayerReligions },
  { label: "Biomes", Component: WELayerBiomes },
  { label: "Heightmap", Component: WELayerHeightmap },
  { label: "Rivers", Component: WELayerRivers },
  { label: "Lakes", Component: WELayerLakes },
  { label: "Routes", Component: WELayerRoutes },
  { label: "Goods", Component: WELayerGoods },
  { label: "Trade", Component: WELayerTrade },
  { label: "Military", Component: WELayerMilitary },
  { label: "Emblems", Component: WELayerEmblems },
  { label: "Labels", Component: WELayerLabels },
  { label: "Burg Icons", Component: WELayerBurgIcons },
  { label: "Markers", Component: WELayerMarkers },
  { label: "Ocean", Component: WELayerOcean },
  { label: "Compass", Component: WELayerCompass },
  { label: "Landmass", Component: WELayerLandmass },
  { label: "Texture", Component: WELayerTexture },
  { label: "Cells", Component: WELayerCells },
  { label: "Grid", Component: WELayerGrid },
  { label: "Coordinates", Component: WELayerCoordinates },
  { label: "Relief", Component: WELayerRelief },
  { label: "Zones", Component: WELayerZones },
  { label: "Borders", Component: WELayerBorders },
  { label: "Temperature", Component: WELayerTemperature },
  { label: "Coastline", Component: WELayerCoastline },
  { label: "Ice", Component: WELayerIce },
  { label: "Markets", Component: WELayerMarkets },
  { label: "Precipitation", Component: WELayerPrecipitation },
  { label: "Population", Component: WELayerPopulation },
  { label: "Fogging", Component: WELayerFogging },
  { label: "Rulers", Component: WELayerRulers },
  { label: "Debug", Component: WELayerDebug },
  { label: "Scale Bar", Component: WELayerScaleBar },
  { label: "Vignette", Component: WELayerVignette },
  { label: "Legend", Component: WELayerLegend },
];

function IconCell({ label, Component, size = 24 }: IconEntry & { size?: number }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      className="flex flex-col items-center gap-2 px-3 py-4 rounded cursor-default group transition-all duration-200"
      style={{
        background: hovered ? "rgba(201,165,82,0.07)" : "transparent",
        border: `1px solid ${hovered ? "rgba(201,165,82,0.25)" : "rgba(37,32,56,0.6)"}`,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        style={{
          color: hovered ? "#c9a552" : "#bdb3a6",
          transition: "color 0.2s",
          filter: hovered ? "drop-shadow(0 0 6px rgba(201,165,82,0.4))" : "none",
        }}
      >
        <Component size={size} strokeWidth={1.5} />
      </div>
      <span
        className="text-center leading-tight"
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: "10px",
          letterSpacing: "0.04em",
          color: hovered ? "#c9a552" : "#58516e",
          transition: "color 0.2s",
          maxWidth: "70px",
          wordBreak: "break-word",
        }}
      >
        {label}
      </span>
    </div>
  );
}

function Section({
  title,
  subtitle,
  icons,
  iconSize = 24,
  accent = false,
}: {
  title: string;
  subtitle?: string;
  icons: IconEntry[];
  iconSize?: number;
  accent?: boolean;
}) {
  return (
    <section style={{ marginBottom: "48px" }}>
      <div style={{ marginBottom: "20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "14px", marginBottom: "6px" }}>
          <h2
            style={{
              fontFamily: "'Cinzel', serif",
              fontSize: "13px",
              fontWeight: 600,
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              color: accent ? "#c9a552" : "#8b8299",
              margin: 0,
            }}
          >
            {title}
          </h2>
          <span
            style={{
              display: "inline-block",
              width: "100%",
              height: "1px",
              background: accent
                ? "linear-gradient(to right, rgba(201,165,82,0.4), transparent)"
                : "linear-gradient(to right, rgba(53,47,82,0.8), transparent)",
            }}
          />
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "10px",
              color: "#3a3552",
              whiteSpace: "nowrap",
              letterSpacing: "0.06em",
            }}
          >
            {icons.length} icons
          </span>
        </div>
        {subtitle && (
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "11px",
              color: "#45405a",
              margin: 0,
              letterSpacing: "0.02em",
            }}
          >
            {subtitle}
          </p>
        )}
      </div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: `repeat(auto-fill, minmax(${iconSize > 28 ? "90px" : "72px"}, 1fr))`,
          gap: "6px",
        }}
      >
        {icons.map(({ label, Component }) => (
          <IconCell key={label} label={label} Component={Component} size={iconSize} />
        ))}
      </div>
    </section>
  );
}

function Divider() {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "16px",
        margin: "40px 0",
      }}
    >
      <div style={{ flex: 1, height: "1px", background: "rgba(37,32,56,0.9)" }} />
      <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
        <div style={{ width: "4px", height: "4px", background: "#352f52", transform: "rotate(45deg)" }} />
        <div style={{ width: "6px", height: "6px", background: "#c9a552", opacity: 0.4, transform: "rotate(45deg)" }} />
        <div style={{ width: "4px", height: "4px", background: "#352f52", transform: "rotate(45deg)" }} />
      </div>
      <div style={{ flex: 1, height: "1px", background: "rgba(37,32,56,0.9)" }} />
    </div>
  );
}

export default function App() {
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#09080f",
        padding: "0",
      }}
    >
      {/* Header */}
      <header
        style={{
          borderBottom: "1px solid #1a1828",
          padding: "40px 64px 36px",
          background: "linear-gradient(180deg, #0f0d1a 0%, #09080f 100%)",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Decorative background elements */}
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background:
              "radial-gradient(ellipse 60% 100% at 50% -20%, rgba(201,165,82,0.05) 0%, transparent 70%)",
            pointerEvents: "none",
          }}
        />
        <div style={{ position: "relative", maxWidth: "1400px", margin: "0 auto" }}>
          {/* Eyebrow */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
              marginBottom: "16px",
            }}
          >
            <div style={{ width: "20px", height: "1px", background: "#352f52" }} />
            <span
              style={{
                fontFamily: "'Cinzel', serif",
                fontSize: "10px",
                letterSpacing: "0.3em",
                color: "#5a5370",
                textTransform: "uppercase",
              }}
            >
              Design System Reference
            </span>
            <div style={{ width: "20px", height: "1px", background: "#352f52" }} />
          </div>

          <h1
            style={{
              fontFamily: "'Cinzel', serif",
              fontSize: "clamp(24px, 4vw, 40px)",
              fontWeight: 600,
              letterSpacing: "0.1em",
              color: "#e2d8c8",
              margin: "0 0 8px",
              lineHeight: 1.15,
            }}
          >
            World Engine
            <span style={{ color: "#c9a552", marginLeft: "0.35em" }}>Icon System</span>
          </h1>

          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "13px",
              color: "#45405a",
              fontWeight: 300,
              letterSpacing: "0.04em",
              margin: "0 0 32px",
              maxWidth: "540px",
            }}
          >
            Proprietary icon language for the Map Creator interface. Every symbol is
            purpose-built for fantasy worldbuilding — combining cartographic craft
            with precision tool aesthetics.
          </p>

          {/* Stats row */}
          {[
            { n: "8", label: "Navigation Categories" },
            { n: "23", label: "Edit Controls" },
            { n: "19", label: "Regenerate Controls" },
            { n: "38", label: "Layer Quick-Rail" },
            { n: "108+", label: "Total Icons" },
          ].map(({ n, label }) => (
            <span
              key={label}
              style={{
                display: "inline-flex",
                flexDirection: "column",
                marginRight: "36px",
                marginBottom: "8px",
              }}
            >
              <span
                style={{
                  fontFamily: "'Cinzel', serif",
                  fontSize: "20px",
                  fontWeight: 600,
                  color: "#c9a552",
                  lineHeight: 1,
                }}
              >
                {n}
              </span>
              <span
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "10px",
                  color: "#45405a",
                  letterSpacing: "0.05em",
                  marginTop: "4px",
                }}
              >
                {label}
              </span>
            </span>
          ))}
        </div>
      </header>

      {/* Main content */}
      <main style={{ maxWidth: "1400px", margin: "0 auto", padding: "56px 64px 80px" }}>

        {/* Primary Navigation */}
        <section style={{ marginBottom: "60px" }}>
          <div style={{ marginBottom: "24px" }}>
            <h2
              style={{
                fontFamily: "'Cinzel', serif",
                fontSize: "10px",
                fontWeight: 600,
                letterSpacing: "0.25em",
                textTransform: "uppercase",
                color: "#c9a552",
                margin: "0 0 6px",
              }}
            >
              Primary Navigation
            </h2>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: "11px", color: "#3a3552", margin: 0 }}>
              Main category buttons of the Map Creator toolbar
            </p>
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(8, 1fr)",
              gap: "8px",
              padding: "24px",
              background: "#0f0d1a",
              border: "1px solid #1a1828",
              borderRadius: "8px",
            }}
          >
            {MAIN_NAV.map(({ label, Component }) => (
              <IconCell key={label} label={label} Component={Component} size={32} />
            ))}
          </div>
        </section>

        <Divider />

        {/* Edit + Regenerate side by side */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "48px", marginBottom: "48px" }}>
          <Section
            title="Edit"
            subtitle="Direct editing controls for every map layer"
            icons={EDIT_ICONS}
          />
          <Section
            title="Regenerate"
            subtitle="Procedural regeneration with refresh arc indicator"
            icons={REGEN_ICONS}
          />
        </div>

        <Divider />

        {/* Smaller utility sections */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: "40px", marginBottom: "48px" }}>
          <Section title="Add" icons={ADD_ICONS} subtitle="Place new elements" />
          <Section title="Show" icons={SHOW_ICONS} subtitle="Display overlays" />
          <Section title="Create" icons={CREATE_ICONS} subtitle="Generate derived maps" />
          <Section title="Heightmap" icons={HEIGHTMAP_ICONS} subtitle="Elevation tools" />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "48px", marginBottom: "48px" }}>
          <Section title="Settings" icons={SETTINGS_ICONS} subtitle="Global configuration" />
          <Section title="File & Map Management" icons={FILE_ICONS} subtitle="Save, load, export" />
        </div>

        <Divider />

        {/* Layer Quick-Rail */}
        <section>
          <div style={{ marginBottom: "28px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "14px", marginBottom: "8px" }}>
              <h2
                style={{
                  fontFamily: "'Cinzel', serif",
                  fontSize: "13px",
                  fontWeight: 600,
                  letterSpacing: "0.18em",
                  textTransform: "uppercase",
                  color: "#c9a552",
                  margin: 0,
                  whiteSpace: "nowrap",
                }}
              >
                Layer Quick-Rail
              </h2>
              <div style={{ flex: 1, height: "1px", background: "linear-gradient(to right, rgba(201,165,82,0.35), transparent)" }} />
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: "10px", color: "#3a3552", letterSpacing: "0.06em", whiteSpace: "nowrap" }}>
                {LAYER_ICONS.length} icons
              </span>
            </div>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: "11px", color: "#45405a", margin: 0 }}>
              Visual layer controls along the bottom of the Map Creator — each icon represents a conceptual stratum of the fantasy world
            </p>
          </div>

          <div
            style={{
              padding: "24px",
              background: "#0a0912",
              border: "1px solid #1a1828",
              borderRadius: "8px",
            }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(68px, 1fr))",
                gap: "4px",
              }}
            >
              {LAYER_ICONS.map(({ label, Component }) => (
                <IconCell key={label} label={label} Component={Component} size={22} />
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer style={{ marginTop: "80px", paddingTop: "32px", borderTop: "1px solid #13111d" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div>
              <div
                style={{
                  fontFamily: "'Cinzel', serif",
                  fontSize: "12px",
                  letterSpacing: "0.2em",
                  color: "#352f52",
                  marginBottom: "6px",
                }}
              >
                WORLD ENGINE
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: "10px", color: "#2a2540", letterSpacing: "0.05em" }}>
                Map Creator Icon System — Internal Design Reference
              </div>
            </div>
            <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
              <div style={{ width: "6px", height: "6px", background: "#c9a552", opacity: 0.3, transform: "rotate(45deg)" }} />
              <div style={{ width: "4px", height: "4px", background: "#352f52", transform: "rotate(45deg)" }} />
              <div style={{ width: "6px", height: "6px", background: "#c9a552", opacity: 0.3, transform: "rotate(45deg)" }} />
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
